import { Canvas } from "@react-three/fiber";
import React from "react";
import "./style.css";
import { Environment, OrbitControls, ScrollControls } from "@react-three/drei";
import MacController from "./MacController";

const App = () => {
  return (
    <div className="w-full h-screen font-['Helvetica Neue']">
      <div className="navbar flex gap-10 pt-10 pb-3 absolute top-0 left-1/2 -translate-x-1/2">
        {[
          "iPhone",
          "iPad",
          "Service",
          "Products",
          "iPhone",
          "iPad",
          "Service",
          "Products",
          "Contact",
        ].map((e, index) => (
          <a
            key={index} // Ensure each child in a list has a unique "key" prop
            href="https://google.com"
            className="text-white line font-400 text-sm"
          >
            {e}
          </a>
        ))}
      </div>
      <div className="absolute text-white flex flex-col items-center top-32 left-1/2 -translate-x-1/2 ">
        <h3 className="masked text-7xl tracking-tighter font-[700]">
          MacBook Pro
        </h3>
        <h5>Oh so Pro !</h5>
        <p className="text-center w-3/4">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet,
          doloribus.
        </p>
      </div>
      <Canvas camera={{ fov: 15, position: [0, -10, 220] }}>
        {/* <OrbitControls /> */}
        <Environment
          files={[
            "https://dl.polyhaven.org/file/ph-assets/HDRIs/exr/4k/brown_photostudio_02_4k.exr",
          ]}
        />
        <ScrollControls pages={3}>
          <MacController />
        </ScrollControls>
        {/* <mesh>
        <boxGeometry />
        </mesh> */}
      </Canvas>
    </div>
  );
};
export default App;
